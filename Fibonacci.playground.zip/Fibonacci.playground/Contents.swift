
// Samet Buğra Oktay week 2- Homework


import UIKit

func fibonacci (n: Int) -> [Int]  {

   
    var fibonacciArray = [Int]()

    for n in 0 ... n {

        if n == 0 {
            fibonacciArray.append(0)
        }
        else if n == 1 {
            fibonacciArray.append(1)
        }
        else {
            fibonacciArray.append (fibonacciArray[n-1] + fibonacciArray[n-2] )
        }
    }
     
    let filter = fibonacciArray.filter{$0 >= 750}
    
    return filter
    
}

print(fibonacci(n: 16)) // [0, 1, 1, 2, 3, 5, 8, 13, 21, 34,55,89,144,233,377,610,987]



